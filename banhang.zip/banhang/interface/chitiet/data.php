<?php 
  $user= trim($_GET['user']);
?>
 <p>Xin chào <?php echo $user; ?></p>