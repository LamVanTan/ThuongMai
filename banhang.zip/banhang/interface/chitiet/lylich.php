<h5 style="text-align: center; background-color: pink;">Lâm Văn Tân<br>
   Lớp : 18i2<br>
   Website : Của Hàng Điện Thoại<br>
   Người Phát Triển Trang Webiste : Lâm Văn Tân<br>
   chấm Hết.
</h5>