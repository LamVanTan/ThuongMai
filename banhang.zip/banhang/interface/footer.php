 <div class="row bg-success" > 
 
		  <div class=" col-md-4">
		  	<ul style="margin-top: 30px;">
		  		<li>Tìm hiểu về mua trả góp</li>
				<li>Chính sách bảo hành</li>
				<li>Chính sách đổi trả</li>
				<li>Giao hàng & Thanh toán</li>
				<li>Xem thêm</li>
		  	</ul>
		  </div>

		  <div class="col-md-4 ">
		  	<ul style="margin-top: 30px;">
			 <li>Giới thiệu công ty (mwg.vn)</li>
			 <li>Tuyển dụng</li>
			 <li>Gửi góp ý, khiếu nại</li>
			 <li>Tìm siêu thị (1947 shop)</li>
			 <li>Xem bản mobile</li>
		  	</ul>
		  </div>

		  <div class="col-md-4">
		  	<ul style="margin-top: 30px;">
				<li>Gọi mua hàng 1800.1060 (7:30 - 22:00)</li>
				<li>Gọi khiếu nại :  1800.1062 (8:00 - 21:30)</li>
				<li>Gọi bảo hành :  1800.1064 (8:00 - 21:00)</li>
				<li>Kỹ thuật : 1800.1763 (7:30 - 22:00)</li>
		  	</ul>
		  </div>
		
 </div>