<form action="model/loaisp/xuly.php" method="POST">
	<div style="background-color: red; color: black; text-align: center;">Thêm</div>
    <div class="form-group">
      <label for="email">Thiết Bị</label>
      <input type="text" class="form-control"  placeholder="thiet bi" name="text">
    </div>
    <div class="form-group">
      <label for="pwd">Thứ Tự</label>
      <input type="text" class="form-control"  placeholder="thứ tự" name="ttu">
    </div>
    <button type="submit" class="btn btn-primary" name="sub">Insert</button>
</form>